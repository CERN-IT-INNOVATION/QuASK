import numpy as np
from ..core import Ansatz, Kernel, KernelType

class QiboKernel(Kernel):
    pass
